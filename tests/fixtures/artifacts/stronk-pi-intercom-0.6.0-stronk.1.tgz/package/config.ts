export const configPath = 'state-root-aware';
