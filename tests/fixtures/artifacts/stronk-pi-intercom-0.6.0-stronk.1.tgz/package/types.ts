export type Intercom = object;
