export function inlineMessage() {}
