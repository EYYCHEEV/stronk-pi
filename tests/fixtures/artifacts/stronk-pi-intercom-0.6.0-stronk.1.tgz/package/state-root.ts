export function getStronkStateRoot() { return ''; }
