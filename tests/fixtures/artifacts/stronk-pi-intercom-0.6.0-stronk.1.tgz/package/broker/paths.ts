export function paths() {}
