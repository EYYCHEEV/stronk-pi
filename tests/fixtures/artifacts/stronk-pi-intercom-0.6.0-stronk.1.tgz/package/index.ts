export default function intercom() {}
