export default function stronkPiFixture() {}
