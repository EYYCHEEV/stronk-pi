export function discoverAvailableSkills() { return []; }
