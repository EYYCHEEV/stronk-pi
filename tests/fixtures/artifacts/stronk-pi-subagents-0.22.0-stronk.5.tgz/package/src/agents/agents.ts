export function discoverAgents() { return []; }
