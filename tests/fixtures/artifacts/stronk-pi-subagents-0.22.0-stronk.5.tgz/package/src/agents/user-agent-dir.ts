export function resolveUserAgentDir() { return process.env.PI_CODING_AGENT_DIR || ''; }
