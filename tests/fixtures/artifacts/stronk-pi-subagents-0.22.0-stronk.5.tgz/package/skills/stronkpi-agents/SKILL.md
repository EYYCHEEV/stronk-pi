---
description: Stronk Pi subagent swarm orchestration
---
